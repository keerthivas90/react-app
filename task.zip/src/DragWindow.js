import React, { Component } from "react";
import Draggable from "react-draggable";
 
 
 class DragWindow extends Component {
  state = {
    disabled: false
  };

  toggleDraggable = () =>
    this.setState(prevState => ({ disabled: !this.state.disabled }));

  render = () => {
    const { disabled } = this.state;

 
  


    return (
      <div className="container">
      
   <Draggable disabled={disabled} bounds="parent">     
<div style={{ width: 200 }} 
className={!disabled ? "draggable" : null}
          >
   <input disabled={!disabled} className="uk-input" id="cont" value="drag me"/>
           
           
          </div>
        </Draggable>
      </div>
    );
  };
}


export default DragWindow;
