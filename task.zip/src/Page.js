import React  from "react";
 import { Link} from "react-router-dom";

class Page extends React.Component{



	render(){
const wrapper = {
	
backgroundColor: "#fff", top: 0, right: 0, left: 0, bottom:0, position: "absolute", 
overflowX: 'hidden'};
 const heading = {
top: 1,
float:'left'

 }
 const button ={
padding:10,
size:15,
float:'left',
marginTop:200
}
		return(

			<>
 

			<div style={wrapper}>

			<p style={heading}>Page 2 </p>
  
 
<center><h1> &lt;Content in page 2	&gt; </h1></center>
  <button style={button}>
       <Link  to="/ ">
      Back
            </Link>
            
       </button>
</div>

</>
			)
	}
}

 

export default Page;
