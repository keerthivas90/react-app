import React from 'react';
import './App.css';
import Footer from "./Footer";
import Header from "./Header";
import Page from "./Page";
import DragWindow from "./DragWindow";




import { 
  BrowserRouter as Router,
  Route , Routes
} from 'react-router-dom';
function App() {
   
document.addEventListener('keydown', function(event){
  if(event.key === "Enter"){
window.open(document.URL,'_blank') ;
 }
   if(event.key === "Escape"){
 window.close(document.URL,'_blank') ;
 }
});

  
  return (
  <>
  <center>
  <DragWindow /> 
  </center>
  <Header />
 
  

  <Router>
    <Footer />
  <Routes>
     
      

  <Route path='/page' element={<Page />} />
 
   
   </Routes>

  </Router>
  
 

   </>
  );
}

export default  App;
