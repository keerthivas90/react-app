import React ,{Component} from 'react';
 
 
class Header extends Component {

  constructor(props) {
super(props);
   

    var today = new Date(),

    time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();

   

    this.state = {

      currentTime: time

    }
  

  }

  render() {

 

    return (
 <header className="header">
  
  
   position :

  <input type="radio" value="Male" name="gender"   checked /> Center

        <input type="radio" value="Female" name="gender"    /> Lower Right
 <p className="head"> Press ESC key to hide the window Enter to show it again      <b style={{color:'#fff'}}>
 { this.state.currentTime } </b></p> 


  </header>
     

    );

  }

}


export default Header;