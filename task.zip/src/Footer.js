import React from 'react';

  import { Link} from "react-router-dom";

const Footer = () => (
  <footer className="footer">
 
  <center><button style={{padding:10,
size:15,
}}>
       <Link  to="/Page">
          PAGE 2
            </Link>

       </button>
       </center> 


  </footer>
);
  
export default Footer;